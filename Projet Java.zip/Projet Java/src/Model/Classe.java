/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.util.HashSet;
import java.util.Set;

/**
 *
 * @author caspar
 */
public class Classe {
    
    int idClasse =0 ; 
    String nom ;      // CP, CE1, Prépa ...
    int nb = 0 ; // Nombre d'élèves dans cette classe 
    // Liste des professeurs intervenant dans la classe 
    private Set<Professeur> listProfesseur = new HashSet<>(); 
    // Liste des élèves dans la classe
    private final Set<Eleve> listEleve = new HashSet<>(); 
    
    
    // Constructeur par défaut 
    public Classe() {
    }
    
    // Constructeur 
    public Classe (int idClasse, String nom, int nb) {
        this.idClasse = idClasse; 
        this.nom = nom ; 
        this.nb=nb; 
    }
    
    
    
    // Méthodes de bases 
    public int getIdClasse() {
        return idClasse;
    }

    public void setIdClasse(int idClasse) {
    this.idClasse = idClasse;
    }
    
    public String getNomClasse() {
        return nom;
    }

    public void setNomClasse(String nom) {
    this.nom = nom;
    }
    
    
    // Avoir la liste des professeurs dans une classe
    public Set<Professeur> getListProfesseur() {
        return listProfesseur ; 
    }
    
    // Setter un liste de professeurs
    public void setListProfesseur(Set<Professeur> listProfesseur){
        this.listProfesseur = listProfesseur ; 
    }
    
    
    // Ajouter des professeurs  à une classe 
    public void addProfesseur(Professeur prof) {
        if(!listProfesseur.contains(prof))    // Si le professeur n'est pas déja dans la liste 
        listProfesseur.add(prof) ;
    }
    
 
    // Enlever un professeur de la liste 
    public void removeProfesseur(Professeur prof) {
        this.listProfesseur.remove(prof); 
    }
    
    
    // Obtenir la liste des élèves dans la classe
    public Set<Eleve> getListEleve() {
        return listEleve; 
    }
    
    // CECI CORRESSPOND A L'ASSOCIATION INSCRIPTION
    // Ajouter un élève à la classe 
    public void addEleve(Eleve eleve) {
        if(this.listEleve.contains(eleve)) {  // Si l'élève n'est pas déja dans la classe 
        this.listEleve.add(eleve);
        }
    }
    
    
    
    // Aucune idée de ce à quoi ça sert mais c'est sur opensclassrooms : 
    public boolean equals(Classe cls) {
        return this.getIdClasse() == cls.getIdClasse(); 
    }
}
        
        
        
         
    
            
    
    


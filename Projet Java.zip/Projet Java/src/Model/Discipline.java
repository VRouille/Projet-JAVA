/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author caspar
 */
public class Discipline {           // La discipline est l'équivalent d'une matière 
    
    // Attributs de Discipline 
    int idDiscipline ; 
    String nom; 
    
    
    // Constructeur 
    public Discipline (int idDiscipline, String nom) {
        this.idDiscipline = idDiscipline ; 
        this.nom = nom ;           
    }
    
    public Discipline(){}
    
    // Fonction qui retourne l'ID de la discipline
    public int getIdDiscipline() {
        return idDiscipline ; 
    }
    
    
    // Fonction qui set l'ID d'une discipline 
    public void setId(int idDiscipline) {
        this.idDiscipline = idDiscipline ; 
    }
    
    
    // Fonction qui retourne le nom de la discipline 
    public String getNom() {
        return nom ; 
    }
    
    // Fonction qui fixe le nom d'une discipline 
    public void setNom(String nom) {
        this.nom = nom ; 
    }
    
    
}

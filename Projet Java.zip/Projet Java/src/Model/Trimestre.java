/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author caspar
 */
public class Trimestre extends AnneeScolaire {
    
    // Attributs de la classe Trimestre 
    int idTrimestre;
    
    int debut; 
    int fin; 
    private final int idTrimeste;
    
    
    
    // Constructeur Trimestre qui hérite des attributs de la classe année scolaire
    public Trimestre(int idAnnee, int idTrimestre, int debut, int fin) {
        super(idAnnee);
        this.idTrimeste = idTrimestre ; 
        this.debut = debut ; 
        this.fin = fin ;     
    }

   
      
}

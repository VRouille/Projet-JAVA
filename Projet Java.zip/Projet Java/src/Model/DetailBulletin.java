/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author caspar
 */
public class DetailBulletin extends Bulletin {
    
    // Attribut détail bulletin 
    int idDetail; 
    String appreciationDetail; 

    /**
     *
     * @param idBulletin
     * @param appreciation
     * @param moyenneg
     * @param classement
     */
    public DetailBulletin(int idBulletin, String appreciation, int moyenneg, int classement) {
        super(idBulletin, appreciation, moyenneg, classement);
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author caspar
 */
public class AnneeScolaire {
    
    // Attribut de l'année scolaire
    int idAnnee ;   
    
    
    
    // Constructeur 
    public AnneeScolaire(int idAnnee) {
        this.idAnnee = idAnnee ;   
    }
    
    // Fonction qui retourne l'id de l'année scolaire 
    public int getIdAnnee() {
        return idAnnee; 
    }
    
    // Fonction qui fixe l'id de l'année scolaire
    public void setIdAnnee(int idAnnee) {      // Void car ne retourne rien
        this.idAnnee = idAnnee ;
    }
    
}

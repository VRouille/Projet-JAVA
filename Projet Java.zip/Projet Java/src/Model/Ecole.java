/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author caspar
 */
public class Ecole {
    
    // Déclaration des attributs
    int idEcole ; 
    String nomEcole ; 
    String adresse ; 
    int telephone;
    
    // Constructeur par défaut 
    public Ecole() {
    }
    
    
    // Constructeur 
    public Ecole (int idEcole, String nomEcole, String adresse, int telephone) {
        this.idEcole = idEcole; 
        this.nomEcole=nomEcole;
        this.adresse=adresse; 
        this.telephone=telephone; 
    }
    
    
    // Fonctions getter et setter de base 
    public int getIdEcole() {
    return idEcole;
    }

    public void setIdEcole(int idEcole) {
    this.idEcole = idEcole;
    }
    
    
    public String getNomEcole() {
    return nomEcole;
    }

    public void setNomEcole(String nomEcole) {
    this.nomEcole = nomEcole;
    }
    
    public String getAdresseEcole() {
    return adresse;
    }

    public void setAdresseEcole(String adresse) {
    this.adresse = adresse;
    }
    
    public int getTelephone() {
    return telephone;
    }

    public void setTelephone(int telephone) {
    this.telephone = telephone;
    }
    
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author caspar
 */
public class Niveau {               // Niveau d'une classe ? 
    
    // Atributs du Niveau           
    int idNiveau; 
    String nom; 
    
    // Constructeur par défaut 
    public Niveau() {
    }
    
    // Constructeur 
    public Niveau (int idNiveau, String nom) {
        this.idNiveau = idNiveau ; 
        this.nom = nom ; 
    }
    
    
    // Getter et setter 
    public int getIdNiveau() {
    return idNiveau;
    }

    public void setIdNiveau(int idNiveau) {
    this.idNiveau = idNiveau;
    }
    
    
    public String getNom() {
    return nom;
    }

    public void setNom(String nom) {
    this.nom = nom;
    }
    
}

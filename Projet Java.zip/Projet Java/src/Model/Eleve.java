/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author caspar
 */
public class Eleve {
    public int idEleve=0; 
    public String nom = ""; 
    public String prenom =""; 
    public int age = 0 ; 
    public String sexe = ""; 
    
    // Constructeur par défaut 
    public Eleve(){  
    }
    
    // Constructeur 
    public Eleve(int idEleve, String nom, String prenom, int age, String sexe) {
        this.idEleve=idEleve; 
        this.nom=nom; 
        this.prenom=prenom; 
        this.age=age;
        this.sexe=sexe; 
    }
    
    
  
    public int getId() {
    return idEleve;
    }
    
    public void setId(int idEleve) {
    this.idEleve = idEleve;
    }

    public String getNom() {
    return nom;
    }

    public void setNom(String nom) {
    this.nom = nom;
    }

    public String getPrenom() {
    return prenom;
    }

    public void setPrenom(String prenom) {
    this.prenom = prenom;
    }  
    
    public int getAge() {
    return age;
    }
    
    public void setAge(int age) {
    this.age = age;
    }
    
    
}

 


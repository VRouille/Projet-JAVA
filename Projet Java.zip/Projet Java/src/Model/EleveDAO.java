/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.sql.Connection;

/**
 *
 * @author caspar
 * @param <T>
 */
public abstract class EleveDAO<T> {
    protected Connection connect = null ; 
    
    // Constructeur 
    public EleveDAO(Connection conn) {
        this.connect = conn ; 
    }
    
    
    /**
  * Méthode de création
  * @param obj
  * @return boolean 
  */
  public boolean create(T obj) {
      return false; 
  }

  /**
  * Méthode pour effacer
  * @param obj
  * @return boolean 
  */
  public boolean delete(T obj){
      return false; 
  }

  /**
  * Méthode de mise à jour
  * @param obj
  * @return boolean
  */
  public boolean update(T obj){
      return false;
  }

  /**
  * Méthode de recherche des informations
  * @param id
  * @return T
  */
  public Eleve find(int id) {
      Eleve eleve = new Eleve();  
        return null;
}
}
    
    


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author caspar
 */
public class Evaluation extends DetailBulletin {
    
    // Attribut de évalution 
    int idEvaluation; 
    float note; 
    String appreciationeval; 
    
    
}

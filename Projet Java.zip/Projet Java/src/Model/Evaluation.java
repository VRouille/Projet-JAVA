/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author caspar
 */
public class Evaluation extends DetailBulletin {
    
    // Attribut de évalution 
    int idEvaluation; 
    float note; 
    String appreciationeval;       

    /**
     *
     * @param idBulletin
     * @param appreciation
     * @param moyenneg
     * @param classement
     */
    // Constructeur qui contient les attributs hérité de la classe mère 
    public Evaluation(int idBulletin, String appreciation, int moyenneg, int classement) {
        super(idBulletin, appreciation, moyenneg, classement);
    }
    
    
   
    /**
     *
     * @param idBulletin
     * @param appreciation
     * @param moyenneg
     * @param classement
     */
    // Conctructeur 
    public void Evaluation(int idBulletin, String appreciation, int moyenneg, int classement) {
        
        this.idBulletin=idBulletin ; 
        this.appreciation=appreciation;
        this.moyenneg=moyenneg;
        this.classement=classement;        
    }
    
    
    // Les getters et setters :
    @Override
    public int getIdBulletin() {
    return idBulletin;
    }

    @Override
    public void setIdBulletin(int idBulletin) {
    this.idBulletin = idBulletin;
    }
    
    @Override
    public String getAppreciation() {
    return appreciation;
    }

    public void setAppreciation(String appreciation) {
    this.appreciation = appreciation;
    }
    
 
    public int getMoyenneG() {
    return moyenneg;
    }

    public void setMoyenneG(int moyenneg) {
    this.moyenneg = moyenneg;
    }
    
    @Override
    public int getClassement() {
    return classement;
    }

    public void Classement(int classement) {
    this.classement = classement;
    }
    
    
    
}

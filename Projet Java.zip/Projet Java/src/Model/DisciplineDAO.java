/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author caspar
 */
public class DisciplineDAO extends DAO<Discipline>{
    
    // Constructeur 
    public DisciplineDAO(Connection conn) {
        super(conn);    
    }
    
    /**
     *
     * @param obj
     * @return
     */
    @Override
    public boolean create(Discipline obj) {
        return false; 
    }
    
    @Override
    public boolean delete(Discipline obj){
        return false; 
    }
    
    /**
     *
     * @param obj
     * @return
     */
    @Override
    public boolean update(Discipline obj){
        return false; 
    }
    
    
    // Trouver une discipline 
    @Override
    public Discipline find(int id) {
        Discipline discipline = new Discipline() ; 
        
        try {
            ResultSet result = this.connect.createStatement(
            
             ResultSet.TYPE_SCROLL_INSENSITIVE,
             ResultSet.CONCUR_READ_ONLY).executeQuery("SELECT * FROM discipline WHERE idDiscipline = " + id);
        if(result.first())
        discipline = new Discipline(id, result.getString("discipline_nom"));         
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return discipline;
  }
}
            
           
            
    

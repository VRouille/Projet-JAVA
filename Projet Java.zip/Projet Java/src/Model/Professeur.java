/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.util.HashSet;
import java.util.Set;

/**
 *
 * @author caspar
 */
public class Professeur {
    
    public int idProfesseur = 0; 
    public String nom = ""; 
    public String prenom = ""; 
    public int age = 0; 
    
    // Liste des disciplines dispensée : 
    private Set<Discipline> listDiscipline = new HashSet<>(); 
    
    
    // Constructeur par défaut 
    public Professeur() {     
    }
    
    public Professeur(int idProfesseur, String nom, String prenom, int age){
        this.idProfesseur = idProfesseur; 
        this.nom = nom ; 
        this.prenom = prenom ; 
        this.age = age ;        
    }
    
    
    
    // Méthodes de base 
    public int getIdProfesseur () {
    return idProfesseur;
    }

    public void setId(int idProfesseur) {
    this.idProfesseur = idProfesseur;
    }

    public String getNom() {
    return nom;
    }

    public void setNom(String nom) {
    this.nom = nom;
    }

    public String getPrenom() {
    return prenom;
    }

    public void setPrenom(String prenom) {
    this.prenom = prenom;
    }

    
    // Méthode pour retourner la liste des disciplines enseignés par le prof 
    public Set<Discipline> getListDiscipline() {
    return listDiscipline;
    }

    // Méthode pour mettre des disciplines à un prof 
    public void setListDiscipline(Set<Discipline> listDiscipline) {
    this.listDiscipline = listDiscipline;
    }

    //Ajoute une discipline à un prof --> corresspond à l'association enseignement 
    public void addDiscipline(Discipline discipline){
    this.listDiscipline.add(discipline);
    }

    //Retirer une discipline à un professeur
    public void removeDiscipline(Discipline discipline){
    this.listDiscipline.remove(discipline);
    }
    
    
    
    
}






// Faire une méthode enseignement 
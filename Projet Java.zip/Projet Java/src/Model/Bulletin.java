/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;
import java.util.Scanner;

/**
 *
 * @author caspar
 */
public class Bulletin {
    
    // Attributs de bulletin 
    int idBulletin ; 
    String appreciation; 
    // Attributs que l'on a rajouté 
    int moyenneg ;  
    int classement ;
    
    
    // Contructeur 
    public Bulletin (int idBulletin, String appreciation, int moyenneg, int classement) {
        this.idBulletin = idBulletin; 
        this.appreciation = appreciation ; 
        this.moyenneg = moyenneg ;
        this.classement = classement ;   
    }
    
    
    /// Fonction qui retourne l'id du bulletin 
    public int getIdBulletin() {
        return idBulletin; 
    }
    
   // Fonction qui fixe l'id du bulletin
    public void setIdBulletin(int idBulletin) {      // Void car ne retourne rien
        this.idBulletin = idBulletin ;
    }
    
    
    // Fonction qui retourne l'appreciation
    public String getAppreciation() {
        return appreciation; 
    }
    
    // Fonction qui fixe l'appreciation (demander à l'utilisateur de tapper l'appréciation pour le bo n élève)
    //public String setAppreciation(int idBulletin) {      
        //Scanner sc = new Scanner(System.in);             // On va demander à l'utilisateur de tapper l'appréciatio,
        //System.out.println("Entrez l'appréciation :");
        //String str = sc.nextLine();
        //str = idBulletin ; 
    
    //}
    
   
    
    /// Fonction qui retourne la moyenne
    public int getMoyenneg() {
        return moyenneg; 
    }
    
   // Fonction qui fixe la moyenne (si l'administrateur veut changer une moyenne ?)
    public void setMoyenneg(int moyenneg) { 
        this.moyenneg = moyenneg ;
    }
    
    
    /// Fonction qui retourne le classement 
    public int getClassement() {
        return classement; 
    }
    
   // Fonction qui fixe la moyenne (si l'administrateur veut changer une moyenne ?)
    public void sgetClassement (int classement) { 
        this.classement = classement ;
    }
    
}


// Questions : ok ces fonctions retourne moyenne machin ect mais s'assurer que c'est pour le bon élève 

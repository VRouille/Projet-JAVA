/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.sql.Connection;

/**
 *
 * @author caspar
 * @param <T>
 */
public abstract class DAO<T> {     // EST CE QUE DAO NE DOIT PAS ETRE UNE INTERFACE (ET PAS UNE CLASSE) 
    
    protected Connection connect = null; 
    
    // Constructeur 
    public DAO (Connection conn){
        this.connect = conn ; 
    }
    
    
    // Méthode pour la création 
    public abstract boolean create (T obj); 
    
    
    // Méthode pour effacer 
    public abstract boolean delete(T obj);
    
    // Méthode pour mettre à jour 
    public abstract boolean update(T obj); 
    
    // Méthode pour rechercher les informations 
    public abstract T find(int id); 
       
}

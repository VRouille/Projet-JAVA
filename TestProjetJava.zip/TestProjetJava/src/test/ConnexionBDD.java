/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import java.sql.*;


/**
 *
 * @author Vincent Rouillé
 */
public class ConnexionBDD {
    //Déclaration des attributs
    private Connection co = null;
    
    public static Connection Connexion(){
        
        try{
            // chargement driver "com.mysql.jdbc.Driver"
            Class.forName("com.mysql.jdbc.Driver"); 
            
            //Connexion à la 
            Connection co = DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","");
            if(co != null){
                System.out.println("Connexion établie");
            }
            else{
                System.out.println("Problème de connexion");
            }
            return co;
        }
        catch(Exception e){
            System.out.println("--> SQLExcepiton: " + e);
            return null;
        }
    }
}

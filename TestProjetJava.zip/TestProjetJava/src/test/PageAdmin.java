/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import java.sql.*;
import javax.swing.JOptionPane;
import net.proteanit.sql.DbUtils;
/**
 *
 * @author Vincent Rouillé
 */
public class PageAdmin extends javax.swing.JFrame {
    
    /*Déclaration des attributs*/
    private Connection co = null;
    private ResultSet rs = null;
    private PreparedStatement ps =null;
    public String sexeprof;
    static String affichageProf;
    static String affichageEleve;
    static String affichageEleveClasse;
    
    /**
     * Creates new form PageAdmin
     */
    public PageAdmin() {
        initComponents();
        
        //Connexion à la base de donnée
        co = ConnexionBDD.Connexion();
        AffichageProf();
        AffichageEleve();
        AffichageClasse();
        AffichageNote();
    }
    
    /*Affiche les données correspondant aux professeurs dans un tableau*/
    public void AffichageProf(){
        try{
            String requete = "select * from prof";
            ps =co.prepareStatement(requete);
            rs = ps.executeQuery();
            tableprof.setModel(DbUtils.resultSetToTableModel(rs));
        }
        catch(Exception e){
            System.out.println("--> SQLException: " + e);
        }
    }
    
    /*Affiche les données correspondant aux élèves dans un tableau*/
    public void AffichageEleve(){
        try{
            String requete = "select * from eleve";
            ps =co.prepareStatement(requete);
            rs = ps.executeQuery();
            tableeleve.setModel(DbUtils.resultSetToTableModel(rs));
        }
        catch(Exception e){
            System.out.println("--> SQLException: " + e);
        }
    }
    
    /*Affiche les données d'un professeur selectionné dans le tableau dans la partie droite de la fenêtre*/
    /*Le but est de pouvoir ensuite modifier les données si besoin directement en recherchant un professeur dans la base de données selon un mot clé*/
    public void AffichageDroitProf(){
        try{
            int row = tableprof.getSelectedRow();
            this.affichageProf = (tableprof.getModel().getValueAt(row, 0).toString());
            String requete = "select * from prof where IDprof = '"+affichageProf+"'";
            ps = co.prepareStatement(requete);
            rs = ps.executeQuery();
            
            if(rs.next()){
                String t1 = rs.getString("IDprof");
                IDprofAffiche.setText(t1);
                String t2 = rs.getString("nom");
                nomprofAffiche.setText(t2);
                String t3 = rs.getString("prenom");
                prenomprofAffiche.setText(t3);
                String t4 = rs.getString("naissance");
                naissanceprofAffiche.setText(t4);
                String t5 = rs.getString("sexe");
                sexeprofAffiche.setText(t5);
                String t6 = rs.getString("adresse");
                adresseprofAffiche.setText(t6);
                String t7 = rs.getString("mobile");
                mobileprofAffiche.setText(t7);
                String t8 = rs.getString("email");
                emailprofAffiche.setText(t8);
                String t9 = rs.getString("matiere");
                matiereprofAffiche.setText(t9);
            }
        }
        catch(Exception e){
            System.out.println("--> SQLException: " + e);
        }
    }
    
     /*Affiche les données d'un élève selectionné dans le tableau dans la partie droite de la fenêtre*/
    /*Le but est de pouvoir ensuite modifier les données si besoin directement en recherchant un élève dans la base de données selon un mot clé*/
    public void AffichageDroitEleve(){
        try{
            int row = tableeleve.getSelectedRow();
            this.affichageEleve = (tableeleve.getModel().getValueAt(row, 0).toString());
            String requete = "select * from eleve where IDeleve = '"+affichageEleve+"'";
            ps = co.prepareStatement(requete);
            rs = ps.executeQuery();
            
            if(rs.next()){
                String t1 = rs.getString("IDeleve");
                IDeleveAffiche.setText(t1);
                String t2 = rs.getString("nom");
                nomeleveAffiche.setText(t2);
                String t3 = rs.getString("prenom");
                prenomeleveAffiche.setText(t3);
                String t4 = rs.getString("naissance");
                naissanceeleveAffiche.setText(t4);
                String t5 = rs.getString("sexe");
                sexeeleveAffiche.setText(t5);
                String t6 = rs.getString("mere");
                mereeleveAffiche.setText(t6);
                String t7 = rs.getString("pere");
                pereeleveAffiche.setText(t7);
                String t8 = rs.getString("adresse");
                adresseeleveAffiche.setText(t8);
                String t9 = rs.getString("fixe");
                fixeeleveAffiche.setText(t9);
                String t10 = rs.getString("mobilemere");
                mobilemereAffiche.setText(t10);
                String t11 = rs.getString("mobilepere");
                mobilepereAffiche.setText(t11);
                String t12 = rs.getString("email");
                emaileleveAffiche.setText(t12);
                String t13 = rs.getString("situation");
                situationparentAffiche.setText(t13);
            }
        }
        catch(Exception e){
            System.out.println("--> SQLException: " + e);
        }
    }
    
    public String gettableEleveresult(){
        return affichageEleve;
    }
    
    /*Affiche les données correspondant aux classes dans un tableau présent dans la partie notes*/
    public void AffichageClasse(){
        try{
            String requete = "select * from classe";
            ps =co.prepareStatement(requete);
            rs = ps.executeQuery();
            listeeleve.setModel(DbUtils.resultSetToTableModel(rs));
        }
        catch(Exception e){
            System.out.println("--> SQLException: " + e);
        }
    }
    
    public void AffichageClasseEleve(){
        try{
            int row = listeeleve.getSelectedRow();
            this.affichageEleveClasse = (listeeleve.getModel().getValueAt(row, 0).toString());
            String requete = "select * from classe where ID = '"+affichageEleveClasse+"'";
            ps = co.prepareStatement(requete);
            rs = ps.executeQuery();
            
            if(rs.next()){
                String t1 = rs.getString("ID");
                IDeleveAffiche3.setText(t1);
                String t2 = rs.getString("nomeleve");
                nomeleveAffiche3.setText(t2);
                String t3 = rs.getString("prenomeleve");
                prenomeleveAffiche3.setText(t3);
                String t4 = rs.getString("niveau");
                niveaueleveAffiche2.setText(t4);
                String t5 = rs.getString("nom");
                classeeleveAffiche2.setText(t5);
            }
        }
        catch(Exception e){
            System.out.println("--> SQLException: " + e);
        }
    }
    
    /*Affiche l'ensemble des notes ajoutées dans un tableau*/
    public void AffichageNote(){
        try{
            String requete = "select * from evaluation";
            ps =co.prepareStatement(requete);
            rs = ps.executeQuery();
            visualisationnote.setModel(DbUtils.resultSetToTableModel(rs));
        }
        catch(Exception e){
            System.out.println("--> SQLException: " + e);
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel2 = new javax.swing.JPanel();
        InscriptionEleve = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        nomeleve = new javax.swing.JTextField();
        prenomeleve = new javax.swing.JTextField();
        naissanceeleve = new javax.swing.JTextField();
        sexchoice = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        pereeleve = new javax.swing.JTextField();
        mereeleve = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        adresseeleve = new javax.swing.JTextArea();
        fixeeleve = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        mobilepere = new javax.swing.JTextField();
        mobilemere = new javax.swing.JTextField();
        emaileleve = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        situation = new javax.swing.JComboBox<>();
        ajouteleve = new javax.swing.JButton();
        jLabel49 = new javax.swing.JLabel();
        IDeleve = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        inscriptionProf = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        nomprof = new javax.swing.JTextField();
        prenomprof = new javax.swing.JTextField();
        jLabel21 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        adresseprof = new javax.swing.JTextArea();
        jLabel23 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        mobileprof = new javax.swing.JTextField();
        emailprof = new javax.swing.JTextField();
        jLabel18 = new javax.swing.JLabel();
        matiereprof = new javax.swing.JComboBox<>();
        ajoutprof = new javax.swing.JButton();
        naissanceprof = new javax.swing.JTextField();
        jRadioButton1 = new javax.swing.JRadioButton();
        jRadioButton2 = new javax.swing.JRadioButton();
        jLabel19 = new javax.swing.JLabel();
        jLabel47 = new javax.swing.JLabel();
        IDprof = new javax.swing.JTextField();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tableprof = new javax.swing.JTable();
        jPanel4 = new javax.swing.JPanel();
        jLabel30 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        nomprofAffiche = new javax.swing.JTextField();
        prenomprofAffiche = new javax.swing.JTextField();
        naissanceprofAffiche = new javax.swing.JTextField();
        sexeprofAffiche = new javax.swing.JTextField();
        adresseprofAffiche = new javax.swing.JTextField();
        mobileprofAffiche = new javax.swing.JTextField();
        emailprofAffiche = new javax.swing.JTextField();
        matiereprofAffiche = new javax.swing.JTextField();
        jLabel32 = new javax.swing.JLabel();
        IDprofAffiche = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        modifieInfoProf = new javax.swing.JButton();
        jLabel31 = new javax.swing.JLabel();
        rechercheproftxt = new javax.swing.JTextField();
        jPanel5 = new javax.swing.JPanel();
        rechercheelevetxt = new javax.swing.JTextField();
        jLabel33 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        tableeleve = new javax.swing.JTable();
        SuppressionEleve = new javax.swing.JButton();
        modifieInfoeleve = new javax.swing.JButton();
        jPanel6 = new javax.swing.JPanel();
        jLabel37 = new javax.swing.JLabel();
        prenomeleveAffiche = new javax.swing.JTextField();
        jLabel36 = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        fixeeleveAffiche = new javax.swing.JTextField();
        jLabel40 = new javax.swing.JLabel();
        jLabel39 = new javax.swing.JLabel();
        situationparentAffiche = new javax.swing.JTextField();
        emaileleveAffiche = new javax.swing.JTextField();
        jLabel43 = new javax.swing.JLabel();
        jLabel46 = new javax.swing.JLabel();
        IDeleveAffiche = new javax.swing.JTextField();
        jLabel45 = new javax.swing.JLabel();
        sexeeleveAffiche = new javax.swing.JTextField();
        jLabel41 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        adresseeleveAffiche = new javax.swing.JTextField();
        pereeleveAffiche = new javax.swing.JTextField();
        jLabel42 = new javax.swing.JLabel();
        mobilepereAffiche = new javax.swing.JTextField();
        mobilemereAffiche = new javax.swing.JTextField();
        jLabel44 = new javax.swing.JLabel();
        naissanceeleveAffiche = new javax.swing.JTextField();
        jLabel35 = new javax.swing.JLabel();
        nomeleveAffiche = new javax.swing.JTextField();
        mereeleveAffiche = new javax.swing.JTextField();
        jButton2 = new javax.swing.JButton();
        jPanel7 = new javax.swing.JPanel();
        jScrollPane5 = new javax.swing.JScrollPane();
        listeeleve = new javax.swing.JTable();
        jLabel48 = new javax.swing.JLabel();
        rechercheclasse = new javax.swing.JTextField();
        nomsujet = new javax.swing.JTextField();
        jLabel50 = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        jLabel61 = new javax.swing.JLabel();
        IDeleveAffiche3 = new javax.swing.JLabel();
        jLabel62 = new javax.swing.JLabel();
        prenomeleveAffiche3 = new javax.swing.JLabel();
        classeeleveAffiche2 = new javax.swing.JLabel();
        jLabel63 = new javax.swing.JLabel();
        jLabel64 = new javax.swing.JLabel();
        nomeleveAffiche3 = new javax.swing.JLabel();
        niveaueleveAffiche2 = new javax.swing.JLabel();
        jLabel65 = new javax.swing.JLabel();
        jLabel70 = new javax.swing.JLabel();
        IDtestAffiche = new javax.swing.JTextField();
        jLabel66 = new javax.swing.JLabel();
        jLabel67 = new javax.swing.JLabel();
        jLabel68 = new javax.swing.JLabel();
        matierenote = new javax.swing.JComboBox<>();
        noteeleve = new javax.swing.JTextField();
        jScrollPane7 = new javax.swing.JScrollPane();
        appreciationtest = new javax.swing.JTextArea();
        jButton4 = new javax.swing.JButton();
        jLabel69 = new javax.swing.JLabel();
        jPanel11 = new javax.swing.JPanel();
        jScrollPane6 = new javax.swing.JScrollPane();
        visualisationnote = new javax.swing.JTable();
        suppressionnote = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Nom :");

        jLabel2.setText("Prénom :");

        jLabel3.setText("Né(e) le");

        jLabel4.setText("Sexe :");

        nomeleve.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nomeleveActionPerformed(evt);
            }
        });

        prenomeleve.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                prenomeleveActionPerformed(evt);
            }
        });

        naissanceeleve.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                naissanceeleveActionPerformed(evt);
            }
        });

        sexchoice.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Féminin", "Masculin" }));
        sexchoice.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sexchoiceActionPerformed(evt);
            }
        });

        jLabel5.setText("Famille");

        jLabel6.setText("Père :");

        jLabel7.setText("Mère :");

        jLabel8.setText("Adresse :");

        jLabel9.setText("Tel Fixe :");

        adresseeleve.setColumns(20);
        adresseeleve.setRows(5);
        jScrollPane1.setViewportView(adresseeleve);

        jLabel10.setText("Tel mobile père :");

        jLabel11.setText("Tel mobile mère :");

        jLabel12.setText("Email :");

        jLabel13.setText("Situation familiale :");

        situation.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Marié", "Pacsé", "Divorcé", "Séparé", "Célibataire", "Veuf" }));
        situation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                situationActionPerformed(evt);
            }
        });

        ajouteleve.setText("Ajouter");
        ajouteleve.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ajouteleveActionPerformed(evt);
            }
        });

        jLabel49.setText("ID :");

        javax.swing.GroupLayout InscriptionEleveLayout = new javax.swing.GroupLayout(InscriptionEleve);
        InscriptionEleve.setLayout(InscriptionEleveLayout);
        InscriptionEleveLayout.setHorizontalGroup(
            InscriptionEleveLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(InscriptionEleveLayout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addGroup(InscriptionEleveLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5)
                    .addGroup(InscriptionEleveLayout.createSequentialGroup()
                        .addGroup(InscriptionEleveLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6)
                            .addGroup(InscriptionEleveLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addGroup(InscriptionEleveLayout.createSequentialGroup()
                                    .addComponent(jLabel2)
                                    .addGap(31, 31, 31)
                                    .addComponent(prenomeleve, javax.swing.GroupLayout.PREFERRED_SIZE, 232, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(InscriptionEleveLayout.createSequentialGroup()
                                    .addGroup(InscriptionEleveLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(InscriptionEleveLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(InscriptionEleveLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addGroup(InscriptionEleveLayout.createSequentialGroup()
                                                    .addComponent(jLabel3)
                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, InscriptionEleveLayout.createSequentialGroup()
                                                    .addComponent(jLabel4)
                                                    .addGap(53, 53, 53)))
                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, InscriptionEleveLayout.createSequentialGroup()
                                                .addComponent(jLabel8)
                                                .addGap(30, 30, 30)))
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, InscriptionEleveLayout.createSequentialGroup()
                                            .addComponent(jLabel9)
                                            .addGap(31, 31, 31)))
                                    .addGroup(InscriptionEleveLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(sexchoice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(naissanceeleve, javax.swing.GroupLayout.DEFAULT_SIZE, 232, Short.MAX_VALUE)
                                        .addComponent(pereeleve)
                                        .addComponent(mereeleve)
                                        .addComponent(jScrollPane1)
                                        .addComponent(fixeeleve)))
                                .addComponent(ajouteleve)
                                .addGroup(InscriptionEleveLayout.createSequentialGroup()
                                    .addGroup(InscriptionEleveLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel1)
                                        .addComponent(jLabel49))
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addGroup(InscriptionEleveLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(nomeleve, javax.swing.GroupLayout.DEFAULT_SIZE, 232, Short.MAX_VALUE)
                                        .addComponent(IDeleve))))
                            .addComponent(jLabel7))
                        .addGap(66, 66, 66)
                        .addGroup(InscriptionEleveLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(InscriptionEleveLayout.createSequentialGroup()
                                .addGroup(InscriptionEleveLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel11)
                                    .addComponent(jLabel10)
                                    .addComponent(jLabel12))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(InscriptionEleveLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(mobilepere, javax.swing.GroupLayout.DEFAULT_SIZE, 237, Short.MAX_VALUE)
                                    .addComponent(mobilemere, javax.swing.GroupLayout.DEFAULT_SIZE, 237, Short.MAX_VALUE)
                                    .addComponent(emaileleve, javax.swing.GroupLayout.DEFAULT_SIZE, 237, Short.MAX_VALUE)))
                            .addGroup(InscriptionEleveLayout.createSequentialGroup()
                                .addComponent(jLabel13)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(situation, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE)))))
                .addGap(252, 252, 252))
        );
        InscriptionEleveLayout.setVerticalGroup(
            InscriptionEleveLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(InscriptionEleveLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(InscriptionEleveLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel49)
                    .addComponent(IDeleve, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(InscriptionEleveLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(nomeleve, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(InscriptionEleveLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(prenomeleve, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(InscriptionEleveLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(naissanceeleve, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(InscriptionEleveLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(sexchoice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(38, 38, 38)
                .addComponent(jLabel5)
                .addGap(18, 18, 18)
                .addGroup(InscriptionEleveLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(pereeleve, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10)
                    .addComponent(mobilepere, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(InscriptionEleveLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(mereeleve, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11)
                    .addComponent(mobilemere, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(InscriptionEleveLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel8)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(InscriptionEleveLayout.createSequentialGroup()
                        .addGroup(InscriptionEleveLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel12)
                            .addComponent(emaileleve, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(InscriptionEleveLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel13)
                            .addComponent(situation, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18)
                .addGroup(InscriptionEleveLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel9)
                    .addComponent(fixeeleve, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(47, 47, 47)
                .addComponent(ajouteleve)
                .addContainerGap(107, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addComponent(InscriptionEleve, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(93, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(0, 2, Short.MAX_VALUE)
                .addComponent(InscriptionEleve, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jTabbedPane1.addTab("Inscription élève", jPanel2);

        jLabel14.setText("Nom :");

        jLabel15.setText("Prénom :");

        jLabel16.setText("Né(e) le");

        jLabel17.setText("Sexe :");

        nomprof.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nomprofActionPerformed(evt);
            }
        });

        prenomprof.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                prenomprofActionPerformed(evt);
            }
        });

        jLabel21.setText("Adresse :");

        adresseprof.setColumns(20);
        adresseprof.setRows(5);
        jScrollPane2.setViewportView(adresseprof);

        jLabel23.setText("Tel mobile :");

        jLabel25.setText("Email :");

        mobileprof.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mobileprofActionPerformed(evt);
            }
        });

        emailprof.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                emailprofActionPerformed(evt);
            }
        });

        jLabel18.setText("Matière :");

        matiereprof.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Français", "Mathématiques", "Histoire-Géographie", "Anglais", "Espagnol", "Allemand", "SVT", "Physique-Chimie", "Technologie", "Arts Plastique", "Musique", "EPS" }));

        ajoutprof.setText("Ajouter");
        ajoutprof.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ajoutprofActionPerformed(evt);
            }
        });

        naissanceprof.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                naissanceprofActionPerformed(evt);
            }
        });

        buttonGroup1.add(jRadioButton1);
        jRadioButton1.setText("Feminin");
        jRadioButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton1ActionPerformed(evt);
            }
        });

        buttonGroup1.add(jRadioButton2);
        jRadioButton2.setText("Masculin");
        jRadioButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton2ActionPerformed(evt);
            }
        });

        jLabel19.setText("Sous la forme YYYY-MM-DD");

        jLabel47.setText("ID :");

        javax.swing.GroupLayout inscriptionProfLayout = new javax.swing.GroupLayout(inscriptionProf);
        inscriptionProf.setLayout(inscriptionProfLayout);
        inscriptionProfLayout.setHorizontalGroup(
            inscriptionProfLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(inscriptionProfLayout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addGroup(inscriptionProfLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel21)
                    .addGroup(inscriptionProfLayout.createSequentialGroup()
                        .addGroup(inscriptionProfLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(inscriptionProfLayout.createSequentialGroup()
                                .addComponent(jLabel15)
                                .addGap(31, 31, 31)
                                .addComponent(prenomprof, javax.swing.GroupLayout.PREFERRED_SIZE, 232, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(inscriptionProfLayout.createSequentialGroup()
                                .addGroup(inscriptionProfLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(inscriptionProfLayout.createSequentialGroup()
                                        .addComponent(jLabel16)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, inscriptionProfLayout.createSequentialGroup()
                                        .addComponent(jLabel17)
                                        .addGap(53, 53, 53)))
                                .addGroup(inscriptionProfLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 232, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(inscriptionProfLayout.createSequentialGroup()
                                        .addComponent(jRadioButton1)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jRadioButton2))
                                    .addComponent(naissanceprof, javax.swing.GroupLayout.PREFERRED_SIZE, 232, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(inscriptionProfLayout.createSequentialGroup()
                                .addGroup(inscriptionProfLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel14)
                                    .addComponent(jLabel47))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(inscriptionProfLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(nomprof, javax.swing.GroupLayout.DEFAULT_SIZE, 232, Short.MAX_VALUE)
                                    .addComponent(IDprof))))
                        .addGap(30, 30, 30)
                        .addComponent(jLabel19))
                    .addGroup(inscriptionProfLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(ajoutprof)
                        .addGroup(inscriptionProfLayout.createSequentialGroup()
                            .addGroup(inscriptionProfLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel23)
                                .addComponent(jLabel25)
                                .addComponent(jLabel18))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addGroup(inscriptionProfLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(matiereprof, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(emailprof, javax.swing.GroupLayout.PREFERRED_SIZE, 232, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(mobileprof, javax.swing.GroupLayout.PREFERRED_SIZE, 232, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(559, Short.MAX_VALUE))
        );
        inscriptionProfLayout.setVerticalGroup(
            inscriptionProfLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(inscriptionProfLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(inscriptionProfLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel47)
                    .addComponent(IDprof, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(inscriptionProfLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel14)
                    .addComponent(nomprof, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(inscriptionProfLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel15)
                    .addComponent(prenomprof, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(inscriptionProfLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel16)
                    .addComponent(naissanceprof, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel19))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(inscriptionProfLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel17)
                    .addComponent(jRadioButton1)
                    .addComponent(jRadioButton2))
                .addGap(18, 18, 18)
                .addGroup(inscriptionProfLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel21)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(32, 32, 32)
                .addGroup(inscriptionProfLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel23)
                    .addComponent(mobileprof, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(inscriptionProfLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel25)
                    .addComponent(emailprof, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(inscriptionProfLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel18)
                    .addComponent(matiereprof, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(61, 61, 61)
                .addComponent(ajoutprof)
                .addContainerGap(96, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(inscriptionProf, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(inscriptionProf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jTabbedPane1.addTab("Inscription professeur", jPanel1);

        tableprof.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tableprof.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableprofMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(tableprof);

        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder("Informations Professeur"));

        jLabel30.setText("Matière :");

        jLabel20.setText("Nom :");

        jLabel29.setText("Email :");

        jLabel24.setText("Né(e) le");

        jLabel27.setText("Adresse :");

        jLabel26.setText("Sexe :");

        jLabel28.setText("Tel mobile :");

        jLabel22.setText("Prénom :");

        nomprofAffiche.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nomprofAfficheActionPerformed(evt);
            }
        });

        matiereprofAffiche.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                matiereprofAfficheActionPerformed(evt);
            }
        });

        jLabel32.setText("ID :");

        IDprofAffiche.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                IDprofAfficheActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel4Layout.createSequentialGroup()
                            .addComponent(jLabel30)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(matiereprofAffiche, javax.swing.GroupLayout.PREFERRED_SIZE, 246, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel4Layout.createSequentialGroup()
                            .addComponent(jLabel29)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(emailprofAffiche, javax.swing.GroupLayout.PREFERRED_SIZE, 246, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel4Layout.createSequentialGroup()
                            .addComponent(jLabel28)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(mobileprofAffiche, javax.swing.GroupLayout.PREFERRED_SIZE, 246, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel20)
                            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(jLabel22)
                                .addComponent(jLabel24, javax.swing.GroupLayout.Alignment.LEADING))
                            .addComponent(jLabel26)
                            .addComponent(jLabel27)
                            .addComponent(jLabel32))
                        .addGap(24, 24, 24)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(adresseprofAffiche, javax.swing.GroupLayout.DEFAULT_SIZE, 246, Short.MAX_VALUE)
                            .addComponent(sexeprofAffiche, javax.swing.GroupLayout.DEFAULT_SIZE, 246, Short.MAX_VALUE)
                            .addComponent(prenomprofAffiche, javax.swing.GroupLayout.DEFAULT_SIZE, 246, Short.MAX_VALUE)
                            .addComponent(nomprofAffiche, javax.swing.GroupLayout.DEFAULT_SIZE, 246, Short.MAX_VALUE)
                            .addComponent(naissanceprofAffiche, javax.swing.GroupLayout.DEFAULT_SIZE, 246, Short.MAX_VALUE)
                            .addComponent(IDprofAffiche))))
                .addGap(56, 56, 56))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel32)
                    .addComponent(IDprofAffiche, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel20)
                            .addComponent(nomprofAffiche, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel22)
                            .addComponent(prenomprofAffiche, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel24)
                            .addComponent(naissanceprofAffiche, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel26))
                    .addComponent(sexeprofAffiche, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel27)
                    .addComponent(adresseprofAffiche, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(39, 39, 39)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel28)
                    .addComponent(mobileprofAffiche, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel29)
                    .addComponent(emailprofAffiche, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel30)
                    .addComponent(matiereprofAffiche, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jButton1.setText("Supprimer");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        modifieInfoProf.setText("Modifier");
        modifieInfoProf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                modifieInfoProfActionPerformed(evt);
            }
        });

        jLabel31.setText("Recherche");

        rechercheproftxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rechercheproftxtActionPerformed(evt);
            }
        });
        rechercheproftxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                rechercheproftxtKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                rechercheproftxtKeyTyped(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(71, 71, 71)
                        .addComponent(jLabel31)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(rechercheproftxt, javax.swing.GroupLayout.PREFERRED_SIZE, 335, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel3Layout.createSequentialGroup()
                            .addGap(39, 39, 39)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel3Layout.createSequentialGroup()
                            .addGap(164, 164, 164)
                            .addComponent(jButton1)
                            .addGap(38, 38, 38)
                            .addComponent(modifieInfoProf))))
                .addGap(18, 18, 18)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(218, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel31)
                    .addComponent(rechercheproftxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 402, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(37, 37, 37)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton1)
                            .addComponent(modifieInfoProf)))
                    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(103, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Recherche professeur", jPanel3);

        rechercheelevetxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                rechercheelevetxtKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                rechercheelevetxtKeyTyped(evt);
            }
        });

        jLabel33.setText("Recherche");

        tableeleve.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tableeleve.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableeleveMouseClicked(evt);
            }
        });
        jScrollPane4.setViewportView(tableeleve);

        SuppressionEleve.setText("Supprimer");
        SuppressionEleve.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SuppressionEleveActionPerformed(evt);
            }
        });

        modifieInfoeleve.setText("Modifier");
        modifieInfoeleve.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                modifieInfoeleveActionPerformed(evt);
            }
        });

        jPanel6.setBorder(javax.swing.BorderFactory.createTitledBorder("Informations de l'élève"));

        jLabel37.setText("Né(e) le");

        jLabel36.setText("Prénom :");

        jLabel34.setText("ID :");

        fixeeleveAffiche.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fixeeleveAfficheActionPerformed(evt);
            }
        });

        jLabel40.setText("Père :");

        jLabel39.setText("Mère :");

        situationparentAffiche.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                situationparentAfficheActionPerformed(evt);
            }
        });

        emaileleveAffiche.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                emaileleveAfficheActionPerformed(evt);
            }
        });

        jLabel43.setText("Téléphone mobile Mère :");

        jLabel46.setText("Situation familiale:");

        IDeleveAffiche.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                IDeleveAfficheActionPerformed(evt);
            }
        });

        jLabel45.setText("Email :");

        jLabel41.setText("Adresse :");

        jLabel38.setText("Sexe :");

        pereeleveAffiche.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pereeleveAfficheActionPerformed(evt);
            }
        });

        jLabel42.setText("Téléphone Fixe :");

        mobilepereAffiche.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mobilepereAfficheActionPerformed(evt);
            }
        });

        mobilemereAffiche.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mobilemereAfficheActionPerformed(evt);
            }
        });

        jLabel44.setText("Téléphone mobile Père :");

        jLabel35.setText("Nom :");

        nomeleveAffiche.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nomeleveAfficheActionPerformed(evt);
            }
        });

        mereeleveAffiche.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mereeleveAfficheActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jLabel40)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(pereeleveAffiche, javax.swing.GroupLayout.PREFERRED_SIZE, 246, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                        .addComponent(jLabel39)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(mereeleveAffiche, javax.swing.GroupLayout.PREFERRED_SIZE, 246, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel35)
                            .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(jLabel36)
                                .addComponent(jLabel37, javax.swing.GroupLayout.Alignment.LEADING))
                            .addComponent(jLabel38)
                            .addComponent(jLabel34))
                        .addGap(24, 24, 24)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(sexeeleveAffiche)
                            .addComponent(prenomeleveAffiche)
                            .addComponent(nomeleveAffiche)
                            .addComponent(naissanceeleveAffiche)
                            .addComponent(IDeleveAffiche, javax.swing.GroupLayout.PREFERRED_SIZE, 246, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jLabel41)
                        .addGap(24, 24, 24)
                        .addComponent(adresseeleveAffiche))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jLabel42)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(fixeeleveAffiche))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jLabel43)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(mobilemereAffiche))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jLabel44)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(mobilepereAffiche))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jLabel45)
                        .addGap(42, 42, 42)
                        .addComponent(emaileleveAffiche))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jLabel46)
                        .addGap(18, 18, 18)
                        .addComponent(situationparentAffiche, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel34)
                    .addComponent(IDeleveAffiche, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel35)
                            .addComponent(nomeleveAffiche, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel36)
                            .addComponent(prenomeleveAffiche, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel37)
                            .addComponent(naissanceeleveAffiche, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel38))
                    .addComponent(sexeeleveAffiche, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel39)
                    .addComponent(mereeleveAffiche, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel40)
                    .addComponent(pereeleveAffiche, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel41)
                    .addComponent(adresseeleveAffiche, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel42)
                    .addComponent(fixeeleveAffiche, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel43)
                    .addComponent(mobilemereAffiche, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel44)
                    .addComponent(mobilepereAffiche, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel45)
                    .addComponent(emaileleveAffiche, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel46)
                    .addComponent(situationparentAffiche, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        jButton2.setText("Gestion Classe");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane4)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addGap(140, 140, 140)
                                .addComponent(SuppressionEleve)
                                .addGap(38, 38, 38)
                                .addComponent(modifieInfoeleve)
                                .addGap(49, 49, 49)
                                .addComponent(jButton2))
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addGap(47, 47, 47)
                                .addComponent(jLabel33)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(rechercheelevetxt, javax.swing.GroupLayout.PREFERRED_SIZE, 402, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 64, Short.MAX_VALUE)))
                .addGap(18, 18, 18)
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(126, 126, 126))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel33)
                            .addComponent(rechercheelevetxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 402, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(37, 37, 37)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(SuppressionEleve)
                            .addComponent(modifieInfoeleve)
                            .addComponent(jButton2))))
                .addGap(81, 81, 81))
        );

        jTabbedPane1.addTab("Elève", jPanel5);

        listeeleve.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        listeeleve.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                listeeleveMouseClicked(evt);
            }
        });
        jScrollPane5.setViewportView(listeeleve);

        jLabel48.setText("Recherche classe :");

        rechercheclasse.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                rechercheclasseKeyReleased(evt);
            }
        });

        jLabel50.setText("NOTE");

        jPanel10.setBorder(javax.swing.BorderFactory.createTitledBorder("Informations de l'élève"));

        jLabel61.setText("Classe :");

        jLabel62.setText("Nom :");

        jLabel63.setText("Niveau :");

        jLabel64.setText("Prénom :");

        jLabel65.setText("ID :");

        jLabel70.setText("ID test :");

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel10Layout.createSequentialGroup()
                                .addComponent(jLabel61)
                                .addGap(18, 18, 18)
                                .addComponent(classeeleveAffiche2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(jPanel10Layout.createSequentialGroup()
                                .addComponent(jLabel63)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(niveaueleveAffiche2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(jPanel10Layout.createSequentialGroup()
                                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel64)
                                    .addComponent(jLabel65)
                                    .addComponent(jLabel62))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(prenomeleveAffiche3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(IDeleveAffiche3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(nomeleveAffiche3, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addComponent(jLabel70)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(IDtestAffiche)))
                .addContainerGap())
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel70)
                    .addComponent(IDtestAffiche, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 11, Short.MAX_VALUE)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel65, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(IDeleveAffiche3, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel62, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(nomeleveAffiche3, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel64)
                    .addComponent(prenomeleveAffiche3, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(niveaueleveAffiche2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel63))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel61)
                    .addComponent(classeeleveAffiche2, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        jLabel66.setText("Choix de la matière :");

        jLabel67.setText("Notes de l'élève :");

        jLabel68.setText("Appréciation :");

        matierenote.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Français", "Mathématiques", "Histoire-Géographie", "Anglais", "Espagnol", "Allemand", "SVT", "Physique-Chimie", "Technologie", "Arts Plastique", "Musique", "EPS" }));

        appreciationtest.setColumns(20);
        appreciationtest.setRows(5);
        jScrollPane7.setViewportView(appreciationtest);

        jButton4.setText("Ajout Note");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jLabel69.setText("Nom du sujet :");

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(jLabel48)
                        .addGap(18, 18, 18)
                        .addComponent(rechercheclasse))
                    .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(51, 51, 51)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel50))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel67)
                            .addComponent(jLabel68))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(noteeleve, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 254, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel66)
                            .addComponent(jLabel69))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(matierenote, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(nomsujet, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(216, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton4)
                .addGap(398, 398, 398))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel48)
                            .addComponent(rechercheclasse, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(35, 35, 35)
                        .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(133, 133, 133))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel7Layout.createSequentialGroup()
                        .addComponent(jLabel50)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel66)
                            .addComponent(matierenote, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel69)
                            .addComponent(nomsujet, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel67)
                            .addComponent(noteeleve, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel68)
                            .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(jButton4)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );

        jTabbedPane1.addTab("Notes", jPanel7);

        visualisationnote.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane6.setViewportView(visualisationnote);

        suppressionnote.setText("Suppression note");
        suppressionnote.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                suppressionnoteActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 987, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addGap(481, 481, 481)
                        .addComponent(suppressionnote)))
                .addContainerGap(139, Short.MAX_VALUE))
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31)
                .addComponent(suppressionnote)
                .addContainerGap(139, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Visualisation Notes", jPanel11);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jTabbedPane1)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jTabbedPane1)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jRadioButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton2ActionPerformed
        sexeprof = "Masculin";
    }//GEN-LAST:event_jRadioButton2ActionPerformed

    private void jRadioButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton1ActionPerformed
        sexeprof = "Feminin";
    }//GEN-LAST:event_jRadioButton1ActionPerformed

    private void naissanceprofActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_naissanceprofActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_naissanceprofActionPerformed

    private void ajoutprofActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ajoutprofActionPerformed
        //Ajouter les données nécessaires concernant un nouveau prof dans la BDD
        try{
            String requete = "insert into prof(IDprof, nom, prenom, naissance, sexe, Adresse, mobile, email, matiere) values(?, ?, ?, ?, ?, ?, ?, ?, ?) ";
            ps = co.prepareStatement(requete);
            ps.setString(1, IDprof.getText());
            ps.setString(2, nomprof.getText());
            ps.setString(3, prenomprof.getText());
            ps.setString(4, naissanceprof.getText());
            ps.setString(5,sexeprof);
            ps.setString(6, adresseprof.getText());
            ps.setString(7, mobileprof.getText());
            ps.setString(8, emailprof.getText());
            ps.setString(9, matiereprof.getSelectedItem().toString());

            ps.execute();
            JOptionPane.showMessageDialog(null, "Ce professeur a été ajouté dans la BBD");
        }
        catch(Exception e){
            System.out.println("--> SQLException: " + e);
        }
        MiseAZeroInscription();
        AffichageProf();
    }//GEN-LAST:event_ajoutprofActionPerformed

    private void emailprofActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_emailprofActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_emailprofActionPerformed

    private void mobileprofActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mobileprofActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_mobileprofActionPerformed

    private void prenomprofActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_prenomprofActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_prenomprofActionPerformed

    private void nomprofActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nomprofActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nomprofActionPerformed

    private void mereeleveAfficheActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mereeleveAfficheActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_mereeleveAfficheActionPerformed

    private void nomeleveAfficheActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nomeleveAfficheActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nomeleveAfficheActionPerformed

    private void mobilemereAfficheActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mobilemereAfficheActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_mobilemereAfficheActionPerformed

    private void mobilepereAfficheActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mobilepereAfficheActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_mobilepereAfficheActionPerformed

    private void pereeleveAfficheActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pereeleveAfficheActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_pereeleveAfficheActionPerformed

    private void IDeleveAfficheActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_IDeleveAfficheActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_IDeleveAfficheActionPerformed

    private void emaileleveAfficheActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_emaileleveAfficheActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_emaileleveAfficheActionPerformed

    private void situationparentAfficheActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_situationparentAfficheActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_situationparentAfficheActionPerformed

    private void fixeeleveAfficheActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fixeeleveAfficheActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fixeeleveAfficheActionPerformed

    private void modifieInfoeleveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_modifieInfoeleveActionPerformed
        /*Modification des informations concernant l'élève*/
        String t1 = nomeleveAffiche.getText();
        String t2 = prenomeleveAffiche.getText();
        String t3 = naissanceeleveAffiche.getText();
        String t4 = sexeeleveAffiche.getText();
        String t5 = mereeleveAffiche.getText();
        String t6 = pereeleveAffiche.getText();
        String t7 = adresseeleveAffiche.getText();
        String t8 = fixeeleveAffiche.getText();
        String t9 = mobilemereAffiche.getText();
        String t10 = mobilepereAffiche.getText();
        String t11 = emaileleveAffiche.getText();
        String t12 = situationparentAffiche.getText();
        String t13 = IDeleveAffiche.getText();

        try{
            if (JOptionPane.showConfirmDialog(null, "Êtes-vous sûr de vouloir modifier les informations concernant cet élève ?","Modifier Elève", JOptionPane.YES_NO_OPTION) == JOptionPane.OK_OPTION) {
                String requete ="update eleve set nom ='"+t1+"', prenom ='"+t2+"',naissance ='"+t3+"',sexe ='"+t4+"',mere ='"+t5+"',pere ='"+t6+"',adresse ='"+t7+"',fixe ='"+t8+"',mobilemere ='"+t9+",mobilepere ='"+t10+",email ='"+t11+",situation ='"+t12+" where IDeleve ='"+t13+"'";
                ps = co.prepareStatement(requete);
                ps.execute();
                System.out.println("Supprimez");
                JOptionPane.showMessageDialog(null, "Informations modifiées");
            }
        }
        catch(Exception e){
            System.out.println("--> SQLException: " + e);
        }
    }//GEN-LAST:event_modifieInfoeleveActionPerformed

    private void SuppressionEleveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SuppressionEleveActionPerformed
        /*Supprimer un élève dans la base de donnée*/
        try{
            if (JOptionPane.showConfirmDialog(null, "Êtes-vous sûr de vouloir supprimer cet élève ?","Supprimer Elève", JOptionPane.YES_NO_OPTION) == JOptionPane.OK_OPTION) {
                String requete = "delete from eleve where IDeleve = ?";
                ps = co.prepareStatement(requete);
                ps.setString(1, IDeleveAffiche.getText());
                ps.execute();
                System.out.println("Cet élève a bien été supprimé !");
                JOptionPane.showMessageDialog(null, "Cet élève a bien été supprimé !");
            }
        }
        catch(Exception e){
            System.out.println("--> SQLException: " + e);
        }
        /*Réaffiche le tableau avec l'élément supprimé*/
        AffichageEleve();
        /*Enlève les informations du professeur que l'on a supprimé dans la partie droite "Informations professeur"*/
        MiseAZero();
    }//GEN-LAST:event_SuppressionEleveActionPerformed

    private void tableeleveMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tableeleveMouseClicked
        /*Lorsque l'on clique sur l'une des lignes qui affiche les données d'un élèves, ses données s'affichent à droite*/
        AffichageDroitEleve();
    }//GEN-LAST:event_tableeleveMouseClicked

    private void rechercheelevetxtKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_rechercheelevetxtKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_rechercheelevetxtKeyTyped

    private void rechercheelevetxtKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_rechercheelevetxtKeyReleased
        /**Barre de recherche
        Affiche ce que l'on recherche en fonction des mot clés que l'utilisateur entre dans la barre de recherche*/
        String requete = "select * from eleve where nom like ?";
        try{
            ps = co.prepareStatement(requete);
            ps.setString(1, "%"+rechercheelevetxt.getText()+"%");
            rs = ps.executeQuery();
            tableeleve.setModel(DbUtils.resultSetToTableModel(rs));
        }
        catch(Exception e){
            System.out.println("--> SQLException: " + e);
        }
    }//GEN-LAST:event_rechercheelevetxtKeyReleased

    private void rechercheproftxtKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_rechercheproftxtKeyTyped

    }//GEN-LAST:event_rechercheproftxtKeyTyped

    private void rechercheproftxtKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_rechercheproftxtKeyReleased
        /**Barre de recherche
        Affiche ce que l'on recherche en fonction des mot clés que l'utilisateur entre dans la barre de recherche*/
        String requete = "select * from prof where nom like ?";
        try{
            ps = co.prepareStatement(requete);
            ps.setString(1, "%"+rechercheproftxt.getText()+"%");
            rs = ps.executeQuery();
            tableprof.setModel(DbUtils.resultSetToTableModel(rs));
        }
        catch(Exception e){
            System.out.println("--> SQLException: " + e);
        }
    }//GEN-LAST:event_rechercheproftxtKeyReleased

    private void rechercheproftxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rechercheproftxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rechercheproftxtActionPerformed

    private void modifieInfoProfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_modifieInfoProfActionPerformed
        /*Modification des informations concernant le professeur*/
        String t1 = nomprofAffiche.getText();
        String t2 = prenomprofAffiche.getText();
        String t3 = naissanceprofAffiche.getText();
        String t4 = sexeprofAffiche.getText();
        String t5 = adresseprofAffiche.getText();
        String t6 = mobileprofAffiche.getText();
        String t7 = emailprofAffiche.getText();
        String t8 = matiereprofAffiche.getText();

        try{
            if (JOptionPane.showConfirmDialog(null, "Êtes-vous sûr de vouloir modifier les informations concernant ce professeur ?","Modifier Professeur", JOptionPane.YES_NO_OPTION) == JOptionPane.OK_OPTION) {
                String requete ="update prof set nom ='"+t1+"', prenom ='"+t2+"',naissance ='"+t3+"',sexe ='"+t4+"',adresse ='"+t5+"',mobile ='"+t6+"',email ='"+t7+"',matiere ='"+t8+"' where nom ='"+t1+"'";
                ps = co.prepareStatement(requete);
                ps.execute();
                System.out.println("Modifiés");
                JOptionPane.showMessageDialog(null, "Informations modifiées");
            }
        }
        catch(Exception e){
            System.out.println("--> SQLException: " + e);
        }
        /*Affiche les informations modifiées dans le tableau*/
        AffichageProf();
    }//GEN-LAST:event_modifieInfoProfActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        /*Supprimer un professeur dans la base de donnée*/
        try{
            if (JOptionPane.showConfirmDialog(null, "Êtes-vous sûr de vouloir supprimer ce professeur ?","Supprimer Professeur", JOptionPane.YES_NO_OPTION) == JOptionPane.OK_OPTION) {
                String requete = "delete from prof where IDprof = ?";
                ps = co.prepareStatement(requete);
                ps.setString(1, IDprofAffiche.getText());
                ps.execute();
                System.out.println("Supprimez");
                JOptionPane.showMessageDialog(null, "Ce professeur a bien été supprimé !");
            }
        }
        catch(Exception e){
            System.out.println("--> SQLException: " + e);
        }
        /*Réaffiche le tableau avec l'élément supprimé*/
        AffichageProf();
        /*Enlève les informations du professeur que l'on a supprimé dans la partie droite "Informations professeur"*/
        MiseAZero();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void IDprofAfficheActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_IDprofAfficheActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_IDprofAfficheActionPerformed

    private void matiereprofAfficheActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_matiereprofAfficheActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_matiereprofAfficheActionPerformed

    private void nomprofAfficheActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nomprofAfficheActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nomprofAfficheActionPerformed

    private void tableprofMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tableprofMouseClicked
        /*Lorsque l'on clique sur l'une des lignes qui affiche les données d'un professeur, ces données s'affichent à droite*/
        AffichageDroitProf();
    }//GEN-LAST:event_tableprofMouseClicked

    private void ajouteleveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ajouteleveActionPerformed
        //Ajouter les données nécessaires concernant un nouveau prof dans la BDD
        try{
            String requete = "insert into eleve(IDeleve, nom, prenom, naissance, sexe, mere, pere, adresse, fixe, mobilemere, mobilepere, email, situation) values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ";
            ps = co.prepareStatement(requete);
            ps.setString(1, IDeleve.getText());
            ps.setString(2, nomeleve.getText());
            ps.setString(3, prenomeleve.getText());
            ps.setString(4, naissanceeleve.getText());
            ps.setString(5, sexchoice.getSelectedItem().toString());
            ps.setString(6,mereeleve.getText());
            ps.setString(7, pereeleve.getText());
            ps.setString(8, adresseeleve.getText());
            ps.setString(9, fixeeleve.getText());
            ps.setString(10, mobilemere.getText());
            ps.setString(11, mobilepere.getText());
            ps.setString(12, emaileleve.getText());
            ps.setString(13, situation.getSelectedItem().toString());

            ps.execute();
            JOptionPane.showMessageDialog(null, "Cet élève a été ajouté dans la BBD");
        }
        catch(Exception e){
            System.out.println("--> SQLException: " + e);
        }
        MiseAZeroInscription();
        AffichageEleve();
    }//GEN-LAST:event_ajouteleveActionPerformed

    private void situationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_situationActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_situationActionPerformed

    private void sexchoiceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sexchoiceActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_sexchoiceActionPerformed

    private void naissanceeleveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_naissanceeleveActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_naissanceeleveActionPerformed

    private void prenomeleveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_prenomeleveActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_prenomeleveActionPerformed

    private void nomeleveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nomeleveActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nomeleveActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        /*Affiche GestionClasse*/
        new GestionClasse().setVisible(true);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void rechercheclasseKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_rechercheclasseKeyReleased
        /**Barre de recherche
        Affiche ce que l'on recherche en fonction des mot clés que l'utilisateur entre dans la barre de recherche*/
        try{
            String requete = "select * from classe where niveau like ?";
            ps = co.prepareStatement(requete);
            ps.setString(1, "%"+rechercheclasse.getText()+"%");
            rs = ps.executeQuery();
            listeeleve.setModel(DbUtils.resultSetToTableModel(rs));
        }
        catch(Exception e){
            System.out.println("--> SQLException: " + e);
        }
    }//GEN-LAST:event_rechercheclasseKeyReleased

    private void listeeleveMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_listeeleveMouseClicked
        /*Lorsque l'on clique, selectionne l'élève pour afficher ses informations à droite*/
        AffichageClasseEleve();
    }//GEN-LAST:event_listeeleveMouseClicked

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        /**/
        try{
            if (JOptionPane.showConfirmDialog(null, "Êtes-vous sûr de vouloir attribuer cette note à cet élève  ?","Note attribue", JOptionPane.YES_NO_OPTION) == JOptionPane.OK_OPTION) {
                String requete = "insert into evaluation(IDnote, ID, nom, prenom, niveau, nomclasse, matière, nomsujet, note, appreciation) values(?,?, ?, ?, ?, ?, ?, ?, ?, ?) ";
                ps = co.prepareStatement(requete);
                ps.setString(1, IDtestAffiche.getText());
                ps.setString(2, IDeleveAffiche3.getText());
                ps.setString(3, nomeleveAffiche3.getText());
                ps.setString(4, prenomeleveAffiche3.getText());
                ps.setString(5, niveaueleveAffiche2.getText());
                ps.setString(6, classeeleveAffiche2.getText());
                ps.setString(7, matierenote.getSelectedItem().toString());
                ps.setString(8, nomsujet.getText());
                ps.setString(9, noteeleve.getText());
                ps.setString(10, appreciationtest.getText());
                ps.execute();
                
                JOptionPane.showMessageDialog(null, "Cette note est attibuée à cet élève");
            }
        }
        catch(Exception e){
            System.out.println("--> SQLException: " + e);
            JOptionPane.showMessageDialog(null, "Vous ne pouvez pas ajouter 2 notes pour le même test pour un même élève");
        }
        AffichageNote();
        MiseAZero();
    }//GEN-LAST:event_jButton4ActionPerformed

    private void suppressionnoteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_suppressionnoteActionPerformed
        /*Supprimer une note dans la base de donnée et dans le tableau de visualisation des notes*/
        try{
            if (JOptionPane.showConfirmDialog(null, "Êtes-vous sûr de vouloir supprimer cette note ?","Supprimer Note", JOptionPane.YES_NO_OPTION) == JOptionPane.OK_OPTION) {
                String requete = "delete from evaluation where IDnote = ?";
                ps = co.prepareStatement(requete);
                ps.setString(1, IDtestAffiche.getText());
                ps.execute();
                System.out.println("Cette note a bien été supprimée !");
                JOptionPane.showMessageDialog(null, "Cette note a bien été supprimée !");
            } 
        }
        catch(Exception e){
            System.out.println("--> SQLException: " + e);
        }
        /*Réaffiche le tableau sans l'élément supprimé*/
    }//GEN-LAST:event_suppressionnoteActionPerformed
    
    public void MiseAZeroInscription(){
            /*Vide les informations entrées dans "Inscription professeur"*/
            IDprofAffiche.setText("");
            nomprof.setText("");
            prenomprof.setText("");
            naissanceprof.setText("");
            adresseprof.setText("");
            mobileprof.setText("");
            emailprof.setText("");
            
            /*Vide les informations entrées dans "Inscription élève"*/
            IDeleve.setText("");
            nomeleve.setText("");
            prenomeleve.setText("");
            naissanceeleve.setText("");
            mereeleve.setText("");
            pereeleve.setText("");
            adresseeleve.setText("");
            fixeeleve.setText("");
            mobilemere.setText("");
            mobilepere.setText("");
            emaileleve.setText("");
        }    
    
    public void MiseAZero(){
        /*Vide la partie de droite lorsque l'on supprime un professeur*/
        nomprofAffiche.setText("");
        prenomprofAffiche.setText("");
        naissanceprofAffiche.setText("");
        sexeprofAffiche.setText("");
        adresseprofAffiche.setText("");
        mobileprofAffiche.setText("");
        emailprofAffiche.setText("");
        matiereprofAffiche.setText("");
        
        /*Vide les informations d'une note*/
        IDtestAffiche.setText("");
        nomsujet.setText("");
        noteeleve.setText("");
        appreciationtest.setText("");
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PageAdmin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PageAdmin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PageAdmin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PageAdmin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PageAdmin().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField IDeleve;
    private javax.swing.JTextField IDeleveAffiche;
    private javax.swing.JLabel IDeleveAffiche1;
    private javax.swing.JLabel IDeleveAffiche2;
    private javax.swing.JLabel IDeleveAffiche3;
    private javax.swing.JTextField IDprof;
    private javax.swing.JTextField IDprofAffiche;
    private javax.swing.JTextField IDtestAffiche;
    private javax.swing.JPanel InscriptionEleve;
    private javax.swing.JButton SuppressionEleve;
    private javax.swing.JTextArea adresseeleve;
    private javax.swing.JTextField adresseeleveAffiche;
    private javax.swing.JTextArea adresseprof;
    private javax.swing.JTextField adresseprofAffiche;
    private javax.swing.JButton ajouteleve;
    private javax.swing.JButton ajoutprof;
    private javax.swing.JTextArea appreciationtest;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JLabel classeeleveAffiche;
    private javax.swing.JLabel classeeleveAffiche1;
    private javax.swing.JLabel classeeleveAffiche2;
    private javax.swing.JTextField emaileleve;
    private javax.swing.JTextField emaileleveAffiche;
    private javax.swing.JTextField emailprof;
    private javax.swing.JTextField emailprofAffiche;
    private javax.swing.JTextField fixeeleve;
    private javax.swing.JTextField fixeeleveAffiche;
    private javax.swing.JPanel inscriptionProf;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel52;
    private javax.swing.JLabel jLabel53;
    private javax.swing.JLabel jLabel54;
    private javax.swing.JLabel jLabel55;
    private javax.swing.JLabel jLabel56;
    private javax.swing.JLabel jLabel57;
    private javax.swing.JLabel jLabel58;
    private javax.swing.JLabel jLabel59;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel60;
    private javax.swing.JLabel jLabel61;
    private javax.swing.JLabel jLabel62;
    private javax.swing.JLabel jLabel63;
    private javax.swing.JLabel jLabel64;
    private javax.swing.JLabel jLabel65;
    private javax.swing.JLabel jLabel66;
    private javax.swing.JLabel jLabel67;
    private javax.swing.JLabel jLabel68;
    private javax.swing.JLabel jLabel69;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel70;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JRadioButton jRadioButton2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTable listeeleve;
    private javax.swing.JComboBox<String> matierenote;
    private javax.swing.JComboBox<String> matiereprof;
    private javax.swing.JTextField matiereprofAffiche;
    private javax.swing.JTextField mereeleve;
    private javax.swing.JTextField mereeleveAffiche;
    private javax.swing.JTextField mobilemere;
    private javax.swing.JTextField mobilemereAffiche;
    private javax.swing.JTextField mobilepere;
    private javax.swing.JTextField mobilepereAffiche;
    private javax.swing.JTextField mobileprof;
    private javax.swing.JTextField mobileprofAffiche;
    private javax.swing.JButton modifieInfoProf;
    private javax.swing.JButton modifieInfoeleve;
    private javax.swing.JTextField naissanceeleve;
    private javax.swing.JTextField naissanceeleveAffiche;
    private javax.swing.JTextField naissanceprof;
    private javax.swing.JTextField naissanceprofAffiche;
    private javax.swing.JLabel niveaueleveAffiche;
    private javax.swing.JLabel niveaueleveAffiche1;
    private javax.swing.JLabel niveaueleveAffiche2;
    private javax.swing.JTextField nomeleve;
    private javax.swing.JTextField nomeleveAffiche;
    private javax.swing.JLabel nomeleveAffiche1;
    private javax.swing.JLabel nomeleveAffiche2;
    private javax.swing.JLabel nomeleveAffiche3;
    private javax.swing.JTextField nomprof;
    private javax.swing.JTextField nomprofAffiche;
    private javax.swing.JTextField nomsujet;
    private javax.swing.JTextField noteeleve;
    private javax.swing.JTextField pereeleve;
    private javax.swing.JTextField pereeleveAffiche;
    private javax.swing.JTextField prenomeleve;
    private javax.swing.JTextField prenomeleveAffiche;
    private javax.swing.JLabel prenomeleveAffiche1;
    private javax.swing.JLabel prenomeleveAffiche2;
    private javax.swing.JLabel prenomeleveAffiche3;
    private javax.swing.JTextField prenomprof;
    private javax.swing.JTextField prenomprofAffiche;
    private javax.swing.JTextField rechercheclasse;
    private javax.swing.JTextField rechercheelevetxt;
    private javax.swing.JTextField rechercheproftxt;
    private javax.swing.JComboBox<String> sexchoice;
    private javax.swing.JTextField sexeeleveAffiche;
    private javax.swing.JTextField sexeprofAffiche;
    private javax.swing.JComboBox<String> situation;
    private javax.swing.JTextField situationparentAffiche;
    private javax.swing.JButton suppressionnote;
    private javax.swing.JTable tableeleve;
    private javax.swing.JTable tableprof;
    private javax.swing.JTable visualisationnote;
    // End of variables declaration//GEN-END:variables

    Object AfficheClasse() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
